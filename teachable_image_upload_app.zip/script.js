const URL = "PASTE_YOUR_MODEL_URL_HERE"; // <-- change this

let model, labelContainer, maxPredictions;

async function initModel() {
    model = await tmImage.load(URL + "model.json", URL + "metadata.json");
    maxPredictions = model.getTotalClasses();

    labelContainer = document.getElementById("label-container");
    labelContainer.innerHTML = "";
    for (let i = 0; i < maxPredictions; i++) {
        labelContainer.appendChild(document.createElement("div"));
    }
}

async function predict(image) {
    const prediction = await model.predict(image);
    for (let i = 0; i < maxPredictions; i++) {
        const className = prediction[i].className;
        const probability = prediction[i].probability.toFixed(2);
        labelContainer.childNodes[i].innerHTML = className + ": " + probability;
    }
}

document.getElementById("imageUpload").addEventListener("change", async function(event) {
    const file = event.target.files[0];
    if (!file) return;

    await initModel();

    const imgElement = document.getElementById("previewImage");
    imgElement.src = URL.createObjectURL(file);
    imgElement.style.display = "block";

    imgElement.onload = function() {
        predict(imgElement);
    };
});
